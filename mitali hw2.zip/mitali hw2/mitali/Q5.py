import os
import base64
from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA
from Crypto.Hash import SHA256
import time

# generation of 1st file
f = open("q5_1kb_file.txt", "w")
f.write(base64.b64encode(os.urandom(1024)).decode())
f.close()

# genertaion of 2nd file
f = open("q5_1mb_file.txt", "w")
f.write(base64.b64encode(os.urandom(1024 * 1024)).decode())
f.close()

# generation of key
time_starts_now = time.time()
rsa_key = RSA.generate(3072)
time_ends_here = time.time()
print(f'Key generated in {time_ends_here - time_starts_now:.4f} seconds')

# creating cipher object
cipher_obj = PKCS1_OAEP.new(rsa_key, hashAlgo=SHA256)

# file 1 encryption
data_size = 256 - 2 * len(os.urandom(10))
input_file = 'q5_1kb_file.txt'
output_file = 'q5_1kb_file.enc'
with open(input_file, 'rb') as input_file, open(output_file, 'wb') as output_file:
    corpus = input_file.read()
    length_pad = cipher_obj._key.size_in_bytes() - len(corpus) % cipher_obj._key.size_in_bytes()
    padded_corpus = corpus + b'\x00' * length_pad
    text_cipher = b''
    time_starts_now = time.time()
    for i in range(0, len(padded_corpus), data_size):
        text_cipher += cipher_obj.encrypt(padded_corpus[i:i+data_size])
    time_ends_here = time.time()
    print(f"Time taken to encrypt {input_file} is {time_ends_here - time_starts_now} seconds")
    print(f"Encryption speed per byte for the file {output_file} is {(len(padded_corpus) / (time_ends_here - time_starts_now)) / 1024 / 1024:.2f} seconds")
    output_file.write(text_cipher)

# file 1 decryption
data_size = cipher_obj._key.size_in_bytes()
input_file = 'q5_1kb_file.enc'
output_file = 'q5_1kb_file.txt'
with open(input_file, 'rb') as input_file, open(output_file, 'wb') as output_file:
    corpus = b''
    time_starts_now = time.time()
    while True:
        chunk = input_file.read(data_size)
        if len(chunk) == 0:
            break
        corpus += cipher_obj.decrypt(chunk)
    end_time = time.time()
    print(f"Time taken to decrypt {input_file} is {end_time - time_starts_now} seconds")
    print(f"Decryption speed per byte for the file {input_file} is {(len(corpus) / (end_time - time_starts_now)) / 1024 / 1024:.2f} seconds")
    end_byte = corpus[-1]
    pad_corners = end_byte if type(end_byte) == int else ord(end_byte)
    unpadded_corpus = corpus[:-pad_corners]
    output_file.write(unpadded_corpus)

# file 2 encryption
data_size = 256 - 2 * len(os.urandom(10))
input_file = 'q5_1mb_file.txt'
output_file = 'q5_1mb_file.enc'
with open(input_file, 'rb') as input_file, open(output_file, 'wb') as output_file:
    corpus = input_file.read()
    length_pad = cipher_obj._key.size_in_bytes() - len(corpus) % cipher_obj._key.size_in_bytes()
    padded_corpus = corpus + b'\x00' * length_pad
    text_cipher = b''
    time_starts_now = time.time()
    for i in range(0, len(padded_corpus), data_size):
        text_cipher += cipher_obj.encrypt(padded_corpus[i:i+data_size])
    time_ends_here = time.time()
    print(f"Time taken to encrypt {input_file} is {time_ends_here - time_starts_now} seconds")
    print(f"Encryption speed per byte for the file {output_file} is {(len(padded_corpus) / (time_ends_here - time_starts_now)) / 1024 / 1024:.2f} seconds")
    output_file.write(text_cipher)

# file 2 decryption
data_size = cipher_obj._key.size_in_bytes()
input_file = 'q5_1mb_file.enc'
output_file = 'q5_1mb_file.txt'
with open(input_file, 'rb') as input_file, open(output_file, 'wb') as output_file:
    corpus = b''
    time_starts_now = time.time()
    while True:
        chunk = input_file.read(data_size)
        if len(chunk) == 0:
            break
        corpus += cipher_obj.decrypt(chunk)
    end_time = time.time()
    print(f"Time taken to decrypt {input_file} is {end_time - time_starts_now} seconds")
    print(f"Decryption speed per byte for the file {input_file} is {(len(corpus) / (end_time - time_starts_now)) / 1024 / 1024:.2f} seconds")
    end_byte = corpus[-1]
    pad_corners = end_byte if type(end_byte) == int else ord(end_byte)
    unpadded_corpus = corpus[:-pad_corners]
    output_file.write(unpadded_corpus)