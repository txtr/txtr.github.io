from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
import os
import time

# generation of 1st file
f = open("q4_1kb_file.txt", "wb")
f.write(os.urandom(1024))
f.close()

# genertaion of 2nd file
f = open("q4_1mb_file.txt", "wb")
f.write(os.urandom(1024 * 1024))
f.close()

# generation of cipher key
time_starts_now = time.time()
rsa_key = RSA.generate(2048)
time_ends_here = time.time()
print(f'Key generated in {time_ends_here - time_starts_now:.4f} seconds')

for input_file in ["q4_1kb_file.txt", "q4_1mb_file.txt"]:
    f = open(input_file, "rb")
    corpus = f.read()
    cipher_for_rsa = PKCS1_OAEP.new(rsa_key.publickey())
    data_size = 190 
    corpus_chunks = [corpus[i:i+data_size] for i in range(0, len(corpus), data_size)]
    time_starts_now = time.time()
    databits_ciphertext = [cipher_for_rsa.encrypt(chunk) for chunk in corpus_chunks]
    time_ends_here = time.time()
    print(f"{input_file} takes encryption time of {time_ends_here - time_starts_now:.6f} seconds")
    print(f"{input_file} takes encryption speed of {len(corpus) / (time_ends_here - time_starts_now):.2f} bytes/second")
    text_cipher_rsa = b"".join(databits_ciphertext)
    f = open(f"{input_file}.enc", "wb")
    f.write(text_cipher_rsa)
    f = open(f"{input_file}.enc", "rb")
    text_cipher_rsa = f.read()
    cipher_for_rsa = PKCS1_OAEP.new(rsa_key)
    time_starts_now = time.time()
    corpus_chunks = [cipher_for_rsa.decrypt(text_cipher_rsa[i:i+256]) for i in range(0, len(text_cipher_rsa), 256)]
    time_ends_here = time.time()
    print(f"{input_file} takes decryption time of {time_ends_here - time_starts_now:.6f} seconds")
    print(f"{input_file} takes decryption speed of {len(corpus) / (time_ends_here - time_starts_now):.2f} bytes/second")
    corpus = b"".join(corpus_chunks)
    f = open(f"{input_file}.dec", "wb")
    f.write(corpus)