import os
import hashlib
import time

f = open('q6_1kb_file.txt', 'wb')
f.write(os.urandom(1024))
f.close()

f = open('q6_10mb_file.txt', 'wb')
f.write(os.urandom(10000000))
f.close()

f = open('q6_1kb_file.txt', 'rb')
time_starts_here = time.time()
sha256_1kb = hashlib.sha256(f.read()).hexdigest()
time_ends_here = time.time()
f.close()

sha256_1kb_time = time_ends_here - time_starts_here
sha256_1kb_byte_time = sha256_1kb_time / 1024

f = open('q6_10mb_file.txt', 'rb')
time_starts_here = time.time()
sha256_10mb = hashlib.sha256(f.read()).hexdigest()
time_ends_here = time.time()
f.close()

sha256_10mb_time = time_ends_here - time_starts_here
sha256_10mb_byte_time = sha256_10mb_time / 10000000

f = open('q6_1kb_file.txt', 'rb')
time_starts_here = time.time()
sha512_1kb = hashlib.sha512(f.read()).hexdigest()
time_ends_here = time.time()
f.close()

sha512_1kb_time = time_ends_here - time_starts_here
sha512_1kb_byte_time = sha512_1kb_time / 1024

f = open('q6_10mb_file.txt', 'rb')
time_starts_here = time.time()
sha512_10mb = hashlib.sha512(f.read()).hexdigest()
time_ends_here = time.time()
f.close()

sha512_10mb_time = time_ends_here - time_starts_here
sha512_10mb_byte_time = sha512_10mb_time / 10000000

f = open('q6_1kb_file.txt', 'rb')
time_starts_here = time.time()
sha3_256_1kb = hashlib.sha3_256(f.read()).hexdigest()
time_ends_here = time.time()
f.close()

sha3_256_1kb_time = time_ends_here - time_starts_here
sha3_256_1kb_byte_time = sha3_256_1kb_time / 1024

f = open('q6_10mb_file.txt', 'rb')
time_starts_here = time.time()
sha3_256_10mb = hashlib.sha3_256(f.read()).hexdigest()
time_ends_here = time.time()
f.close()

sha3_256_10mb_time = time_ends_here - time_starts_here
sha3_256_10mb_byte_time = sha3_256_10mb_time / 10000000

print(f'Sha 256 time taken for q6_1kb_file.txt is {sha256_1kb_time:.6f} seconds')
print(f'Sha 256 time taken for q6_10mb_file.txt is {sha256_10mb_time:.6f} seconds')
print(f'Sha 256 per-byte time taken for q6_1kb_file.txt is {sha256_1kb_byte_time:.12f} seconds')
print(f'SHA-256 per-byte time taken for q6_10mb_file.txt is {sha256_10mb_byte_time:.12f} seconds')
print(f'Sha 512 time taken for q6_1kb_file.txt is {sha512_1kb_time:.6f} seconds')
print(f'Sha 512 time taken for q6_10mb_file.txt is {sha512_10mb_time:.6f} seconds')
print(f'Sha 512 per-byte time taken for q6_1kb_file.txt is {sha512_1kb_byte_time:.12f} seconds')
print(f'Sha 512 per-byte time taken for q6_10mb_file.txt is {sha512_10mb_byte_time:.12f} seconds')
print(f'Sha3 256 time taken for q6_1kb_file.txt is {sha3_256_1kb_time:.6f} seconds')
print(f'Sha3 256 time taken for q6_10mb_file.txt is {sha3_256_10mb_time:.6f} seconds')
print(f'Sha3 256 per-byte time taken for q6_1kb_file.txt is {sha3_256_1kb_byte_time:.12f} seconds')
print(f'Sha3 256 per-byte time taken for q6_10mb_file.txt is {sha3_256_10mb_byte_time:.12f} seconds')