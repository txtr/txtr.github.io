from Crypto.PublicKey import DSA
from Crypto.Signature import DSS
from Crypto.PublicKey import ECC
import os
from Crypto.Hash import SHA256
import time

# generate files which are required
size_of_1st_file = 1024
size_of_2nd_file = 10 * 1024 * 1024
data_1st_file = os.urandom(size_of_1st_file)
data_2nd_file = os.urandom(size_of_2nd_file)

# generating key
time_starts_here = time.time()
dsa_key = DSA.generate(2048, randfunc=os.urandom)
dsa_key._keydata[1] = 224
time_ends_here = time.time()
print(f"Time taken to generate the dsa key is {time_ends_here - time_starts_here} seconds")

# signature generation for 1kb file
time_starts_here1 = time.time()
h = SHA256.new(data_1st_file)
signatory = DSS.new(dsa_key, 'deterministic-rfc6979')
sign1 = signatory.sign(h)
time_ends_here1 = time.time()
print(f"Time taken to generate signature for 1kb file is  {time_ends_here1 - time_starts_here1} seconds")
print(f"Time taken for per-byte signature generation of 1kb file is {(time_ends_here1 - time_starts_here1) / size_of_1st_file} seconds")

# signature generation for 10mb file
time_starts_here2 = time.time()
h = SHA256.new(data_2nd_file)
signatory = DSS.new(dsa_key, 'deterministic-rfc6979')
sign2 = signatory.sign(h)
time_ends_here2 = time.time()
print(f"Time taken to generate signature for 10mb file is {time_ends_here2 - time_starts_here2} seconds")
print(f"Time taken for per-byte signature generation of 10mb file is {(time_ends_here2 - time_starts_here2) / size_of_2nd_file} seconds")

# signature verification for both the files
verifying_authority = DSS.new(dsa_key.publickey(), 'deterministic-rfc6979')
verify_time_starts_here1 = time.time()
h = SHA256.new(data_1st_file)
try:
    verifying_authority.verify(h, sign1)
    print("Successfull validation of signature for 1kb file")
except ValueError:
    print("Unsuccessfull signature validation for 1kb file")
verify_time_ends_here1 = time.time()
print(f"Time taken to verify signature of 1kb file is {verify_time_ends_here1 - verify_time_starts_here1} seconds")
print(f"Time taken to verify per byte of 1kb file is {(verify_time_ends_here1 - verify_time_starts_here1) / size_of_1st_file} seconds")
verify_time_starts_here2 = time.time()
h = SHA256.new(data_2nd_file)
try:
    verifying_authority.verify(h, sign2)
    print("Successfull validation of signature for 10mb file")
except ValueError:
    print("Unsuccessfull signature validation for 10mb file")
verify_time_ends_here2 = time.time()
print(f"Time taken to verify signature of 10mb file is {verify_time_ends_here2 - verify_time_starts_here2} seconds")
print(f"Time taken to verify per byte of 10mb file is {(verify_time_ends_here2 - verify_time_starts_here2) / size_of_2nd_file} seconds")