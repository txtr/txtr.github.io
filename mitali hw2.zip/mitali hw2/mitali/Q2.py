import os
from Crypto.Cipher import AES
import random as rand
import time

# generation of first file
random_file_1 = 'q2_1kb_file.txt'
random_file_size_1 = 1024  
f = open(random_file_1, 'w')
rand_cho = rand.choices('abcdefghijklmnopqrstuvwxyz', k=random_file_size_1)
f.write(''.join(rand_cho))
print(f'{random_file_1} made')
f.close()

# generation of 2nd file
random_file_2 = 'q2_1mb_file.txt'
random_file_size_2 = 10 * 1024 * 1024
f = open(random_file_2, 'w')
rand_cho_2 = rand.choices('abcdefghijklmnopqrstuvwxyz', k=random_file_size_1)
f.write(''.join(rand_cho_2))
print(f'{random_file_2} made')
f.close()

# generation of cipher key
time_starts_now = time.time()
generated_key = os.urandom(16)
time_ends_here = time.time()
print(f'Key generated in {time_ends_here - time_starts_now:.4f} seconds')

# encryption of 1st file
time_starts_now = time.time()
total_data_size = 64 * 1024
encrypt_out_filename = os.path.splitext(random_file_1)[0] + '.enc'
initialization_vector = os.urandom(8)
encyption_object = AES.new(generated_key, AES.MODE_CTR, nonce=initialization_vector)
size_of_file = os.path.getsize(random_file_1)
with open(random_file_1, 'rb') as input_filing_parts:
    with open(encrypt_out_filename, 'wb') as output_filing_parts:
        output_filing_parts.write(size_of_file.to_bytes(8, byteorder='big'))
        output_filing_parts.write(initialization_vector)
        while True:
            data_parts = input_filing_parts.read(total_data_size)
            if len(data_parts) == 0:
                break
            elif len(data_parts) % 16 != 0:
                data_parts += b' ' * (16 - len(data_parts) % 16)
            output_filing_parts.write(encyption_object.encrypt(data_parts))
print(f'{random_file_1} done with encryption')
time_ends_here = time.time()
elapsed_time = time_ends_here - time_starts_now
speed_per_byte = elapsed_time / random_file_size_1
print(f'Time taken to encrypt {random_file_1} is {elapsed_time:.4f} seconds')
print(f'Encryption speed per byte for {random_file_1} is {speed_per_byte:.8f} seconds/byte')

# decryption of 1st file
time_starts_now = time.time()
decrypt_file_input_path = os.path.splitext(random_file_1)[0] + ".enc"
total_data_size=24 * 1024
decrypt_out_filename = os.path.splitext(decrypt_file_input_path)[0] + '.txt'
with open(decrypt_file_input_path, 'rb') as input_filing_parts:
    size_of_file = int.from_bytes(input_filing_parts.read(8), byteorder='big')
    initialization_vector = input_filing_parts.read(8)
    decryptor = AES.new(generated_key, AES.MODE_CTR, nonce = initialization_vector)
    with open(decrypt_out_filename, 'wb') as output_filing_parts:
        while True:
            data_parts = input_filing_parts.read(total_data_size)
            if len(data_parts) == 0:
                break
            output_filing_parts.write(decryptor.decrypt(data_parts))
        output_filing_parts.truncate(size_of_file)
print(f'{decrypt_file_input_path} done with decryption')
time_ends_here = time.time()
elapsed_time = time_ends_here - time_starts_now
speed_per_byte = elapsed_time / random_file_size_1
print(f'Time taken to decrypt {random_file_1} is {elapsed_time:.4f} seconds')
print(f'Decryption speed per byte for {random_file_1} is {speed_per_byte:.8f} seconds/byte')

# encryption of 2nd file
time_starts_now = time.time()
total_data_size = 64 * 1024
encrypt_out_filename = os.path.splitext(random_file_2)[0] + '.enc'
initialization_vector = os.urandom(8)
encyption_object = AES.new(generated_key, AES.MODE_CTR, nonce=initialization_vector)
size_of_file = os.path.getsize(random_file_2)
with open(random_file_2, 'rb') as input_filing_parts:
    with open(encrypt_out_filename, 'wb') as output_filing_parts:
        output_filing_parts.write(size_of_file.to_bytes(8, byteorder='big'))
        output_filing_parts.write(initialization_vector)
        while True:
            data_parts = input_filing_parts.read(total_data_size)
            if len(data_parts) == 0:
                break
            elif len(data_parts) % 16 != 0:
                data_parts += b' ' * (16 - len(data_parts) % 16)
            output_filing_parts.write(encyption_object.encrypt(data_parts))
print(f'{random_file_2} done with encryption')
time_ends_here = time.time()
elapsed_time = time_ends_here - time_starts_now
speed_per_byte = elapsed_time / random_file_size_2
print(f'Time taken to encrypt {random_file_2} is {elapsed_time:.4f} seconds')
print(f'Encryption speed per byte for {random_file_2} is {speed_per_byte:.8f} seconds/byte')

# decryption of 2nd file
time_starts_now = time.time()
decrypt_file_input_path = os.path.splitext(random_file_2)[0] + ".enc"
total_data_size=24 * 1024
decrypt_out_filename = os.path.splitext(decrypt_file_input_path)[0] + '.txt'
with open(decrypt_file_input_path, 'rb') as input_filing_parts:
    size_of_file = int.from_bytes(input_filing_parts.read(8), byteorder='big')
    initialization_vector = input_filing_parts.read(8)
    decryptor = AES.new(generated_key, AES.MODE_CTR, nonce = initialization_vector)
    with open(decrypt_out_filename, 'wb') as output_filing_parts:
        while True:
            data_parts = input_filing_parts.read(total_data_size)
            if len(data_parts) == 0:
                break
            output_filing_parts.write(decryptor.decrypt(data_parts))
        output_filing_parts.truncate(size_of_file)
print(f'{decrypt_file_input_path} done with decryption')
time_ends_here = time.time()
elapsed_time = time_ends_here - time_starts_now
speed_per_byte = elapsed_time / random_file_size_2
print(f'Time taken to decrypt {random_file_2} is {elapsed_time:.4f} seconds')
print(f'Decryption speed per byte for {random_file_2} is {speed_per_byte:.8f} seconds/byte')